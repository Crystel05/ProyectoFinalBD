CREATE PROCEDURE [dbo].[SP_ObtenerAnnos] @outResultCode int output
AS

BEGIN

SET NOCOUNT ON

	BEGIN TRY
		
		SELECT DISTINCT Anno FROM dbo.InstanciaGiro
		
	END TRY

	BEGIN CATCH

		INSERT INTO dbo.errores VALUES(
			SUSER_NAME(),
			ERROR_NUMBER(),
			ERROR_STATE(),
			ERROR_SEVERITY(),
			ERROR_LINE(),
			ERROR_PROCEDURE(),
			ERROR_MESSAGE(),
			GETDATE()
		);

		SET @outResultCode = 50001

	END CATCH

	SELECT @outResultCode AS N

SET NOCOUNT OFF

END
go

